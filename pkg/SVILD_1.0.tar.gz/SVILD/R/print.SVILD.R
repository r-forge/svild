print.SVILD <-
function(x,...){
class(x) = NULL
return(x[1:3])
}

